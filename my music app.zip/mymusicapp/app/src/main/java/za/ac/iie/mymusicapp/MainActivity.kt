package za.ac.iie.mymusicapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import za.ac.iie.mymusicapp.Detailscreen
import za.ac.iie.mymusicapp.R.id.nextBtn
import kotlin.reflect.KFunction0
import za.ac.iie.mymusicapp.Detailscreen as Detailscreen1

class MainActivity : AppCompatActivity() {
    private fun intent(packagecontext: Nothing?) {


    }

    private fun intent(packagecontext: MainActivity, java: Class<Detailscreen1>): Intent? {


        return TODO("Provide the return value")
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        val nextBtn : Button = findViewById(nextBtn)
        val exitbtn : Button = findViewById(R.id.exitbtn)
        val playlistbtn : Button = findViewById(R.id.playlistbtn)

        nextBtn.setOnClickListener {
            startActivity(intent(this,Detailscreen::class.java))
        }

        playlistbtn.setOnClickListener {
            Toast.makeText(this@MainActivity, "please enter details of your playlist", Toast.LENGTH_LONG).show()
        }

        exitbtn.setOnClickListener {
            finish()

        }







        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private infix fun Detailscreen(javaClass: Class<KFunction0<Detailscreen1>>): Any {
        TODO("Not yet implemented")
    }
}